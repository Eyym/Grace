import java.util.Date;

//ѧ����
public class Students {
  /**
   * ��ѭJavaBeans���ԭ��
   * ���е���
   * �ṩ���еĲ���������Ĭ�Ϲ��췽��
   * ����˽��
   * ������getter/setter��װ
   */
	
	private int sid;  //ѧ��
	private String name;//
	private String gender;//�Ա�
	private Date birthday;//��������
	private String adress;//��ַ
	
	public Students() {
		
	}

	public Students(int sid, String name, String gender, Date birthday, String adress) {
		//super();
		this.sid = sid;
		this.name = name;
		this.gender = gender;
		this.birthday = birthday;
		this.adress = adress;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	@Override
	public String toString() {
		return "ѧ�� [sid=" + sid + ", name=" + name + ", gender=" + gender + ", birthday=" + birthday + ", adress="
				+ adress + "]";
	}
	
}
