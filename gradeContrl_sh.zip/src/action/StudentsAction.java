package action;

import java.text.SimpleDateFormat;
import java.util.List;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import entity.Students;
import service.StudentsDAO;
import service.impl.StudentsDAOimpl;

public class StudentsAction extends SuperAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// ��ѯ����ѧ���Ķ���
	public String query() {
		StudentsDAO sdao = new StudentsDAOimpl();
		List<Students> list = sdao.queryAllStudents();
		// ��list����session
		if (list != null && list.size() > 0) {
			session.setAttribute("students_list", list);
		}
		return "query_success";
	}

	// ɾ��ѧ����Ϣ����
	public String delete() {
		StudentsDAO sdao = new StudentsDAOimpl();
		String sid = request.getParameter("sid");
		sdao.deteleStudents(sid);

		return "delete_success";
	}

	// �޸�ѧ����Ϣ
	public String modify()  {
		// ��ô�������ѧ��id
		String sid = request.getParameter("sid");

		StudentsDAO sdao = new StudentsDAOimpl();
		Students s = sdao.queryStudentsBySid(sid);
		// ������session��
		session.setAttribute("modify_students", s);

//		String address = request.getParameter("address");
//		String sname = request.getParameter("sname");
//		String gender = request.getParameter("gender");
//		String birthday = request.getParameter("birthday");
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//
//		Students s = new Students();
//		s.setSid(sid);
//		s.setBirthday(sdf.parse(birthday));
//		s.setAddress(address);
//		s.setSname(sname);
//		s.setGender(gender);

		return "modify_success";
	}

	// ����ѧ��
	public String add() throws Exception {
		Students s = new Students();
		s.setSname(request.getParameter("sname"));
		s.setGender(request.getParameter("gender"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		s.setBirthday(sdf.parse(request.getParameter("birthday")));
		s.setAddress(request.getParameter("address"));
		StudentsDAO sdao = new StudentsDAOimpl();
		sdao.addStudents(s);
		return "add_success";
	}
	
	//�����޸ĺ��ѧ����Ϣ
	public String save() throws Exception {
		Students s = new Students();
		s.setSid(request.getParameter("sid"));
		s.setSname(request.getParameter("sname"));
		s.setGender(request.getParameter("gender"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		s.setBirthday(sdf.parse(request.getParameter("birthday")));
		s.setAddress(request.getParameter("address"));
		StudentsDAO sdao = new StudentsDAOimpl();
		sdao.updateStudents(s);
		return "save_success";
		
	}
}
