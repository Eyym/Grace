package service.impl;

import java.util.Date;
import java.util.List;
import org.junit.Test;
import entity.Students;
import junit.framework.Assert;
import service.StudentsDAO;

public class TestStudentsDAOimpl {

	@Test
	public void testQueryAllStudents() {
		StudentsDAO sdao = new StudentsDAOimpl();
		List<Students> list = sdao.queryAllStudents();
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
	}

	@Test
	public void testGetNewSid() {
		StudentsDAOimpl sdao = new StudentsDAOimpl();
		// System.out.println(sdao.getNewSid());
	}

	@Test
	public void testAddStudents() {
		Students s = new Students();
		s.setSname("����");
		s.setGender("��");
		s.setBirthday(new Date());
		s.setAddress("�䵱");
		StudentsDAO sdao = new StudentsDAOimpl();
		Assert.assertEquals(true, sdao.addStudents(s));
	}
}
